clc
close all
clear all 

arco  = imread('arco.jpg');
balon = imread('balon.jpg');

balon_peque = imresize(balon, 0.1);

figure()
imshow(arco)

matriz_negra = uint8(zeros(size(arco)));

matriz_negra(121:160,321:380,:) = balon_peque;

im_salida = arco + matriz_negra;
figure()
subplot(1,2,1),imshow(matriz_negra)
subplot(1,2,2),imshow(im_salida)





