clc

imagen=imread('semillas.jpg');


imagen = rgb2gray(imagen);

doubleimagen=double(imagen)
%[f,c]=size(doubleimagen);
%for i=1:f
 %for j=1:c
 
% imagen_out = zeros (f,c);
%clear imagen_out 
 if imagen < 100 %(i,j)
   imagen_out = doubleimagen*0,1 ; %(i,j)
 else if imagen <  150 
  imagen_out = doubleimagen*1; %(i,j)
  end
 end
 
max( max ( imagen_out);

 
 %end
%end

%imagen_out

%imagen_bin = uint8(imagen_out);

%imagen_out = uint8(imagen_out)

imshow(imagen);
figure(2)
imshow(imagen_out);
