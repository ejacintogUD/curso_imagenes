clear all
close all

arco  = imread('arco.jpg');
balon = imread('balon.jpg');

m_negra = zeros(size(arco));
baloncito = imresize(balon, 0.1, 'bicubic');

m_negra(201:240,151:210,:) = baloncito;


salida = bitxor(arco, uint8(m_negra));

figure()
imshow(salida)
