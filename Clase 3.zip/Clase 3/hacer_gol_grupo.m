clc
clear all 
close all

arco1 = imread('arco.jpg');

balon1 = imread('balon.jpg'); 

figure()
subplot(1,2,1), imshow(arco1)
subplot(1,2,2), imshow(balon1)

balon_peque = imresize(balon1,0.1); 

mascara = uint8(zeros(size(arco1)));

mascara(100:139,225:284,:) = balon_peque;

salida = (double (arco1+50) +  double(mascara*0.6));

salida = uint8(salida ./ (max(max((salida))))*255);

figure()
imshow(salida)