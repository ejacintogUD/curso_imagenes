clc 
close all
clear all

m_arco = imread('arco.jpg');

m_balon = imread('balon.jpg');

baloncito = imresize(m_balon, 0.1, 'bicubic');

d = size(m_arco);

fondo = uint8(zeros(d(1),d(2),3));

fondo(151:190,201:260,:) = baloncito;

fondo = fondo*0.8;

salida = fondo + m_arco;
figure()
imshow(salida);

v_fondo = fondo(:,230,:);

 for i = 1:399
    d_fondo(i) = v_fondo(i+1) - v_fondo(i);
 end


figure()
plot(d_fondo)


