clc
%abre las imagenes
imagen1  = imread('cesped.jpg');
imagen2  = imread('balon.jpg');
imagen3  = imread('arco.jpg');

im1_max = max(max (imagen1(:,:,1)))
im2_max = max(max (imagen2(:,:,1)))

im1_n = double (imagen1);
im2_n = double (imagen2);

im1_n = (im1_n/(double(im1_max)));
im2_n = (im2_n/(double(im2_max)));

imagen4 =   uint8(((im1_n .* im2_n))*255) ;

a=ones(100);
b=zeros(20);
%visualiza las 3 imagenes
a(1:20,1:20)= b;
subplot(1,3,1), imshow(a)
subplot(1,3,2), imshow(imagen2)
subplot(1,3,3), imshow(imagen4)