clc
close all
close all

arco  = imread('arco.jpg');

balon = imread('balon.jpg');

balon_peque = imresize(balon,0.1);

im_ceros = uint8(zeros(size(arco)));

im_ceros(200:239,200:259,:) = balon_peque;

im_salida = (double(arco) + double(im_ceros)) ;

im_salida = im_salida / max((max(max((im_salida)))));

im_salida = uint8(im_salida *255);


figure() 
imshow(im_salida)