clc

%abre la imagen
imagen  = imread('flor.jpg');

%convierte a grises
imagen;
imagen = rgb2gray(imagen);
imagen2 = imagen;
    %imagen2 = imresize(imagen,0.1);
   
    imagen3 = imresize(imagen2,3,'nearest');
    imagen4 = imresize(imagen2,3,'bilinear');
    imagen5 = imresize(imagen2,3,'bicubic');
    
    
%visualiza las 2 imagenes
%subplot(1,4,1), 

imshow(imagen2)

figure(2)
subplot(1,3,1), imshow(imagen3)
subplot(1,3,2), imshow(imagen4)
subplot(1,3,3), imshow(imagen5)
%subplot(1,2,2), imshow(imagenTemp)