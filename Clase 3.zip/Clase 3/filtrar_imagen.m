%este programa muestra como se realiza un filtro en Matlab
clc

%imagen1 = imread('desierto.jpg');  %funcion para abrir imagenes

imagen1 = imread('flor.jpg');  %funcion para abrir imagenes

%imagen1 = imresize(imagen1, 0.5);
figure(1)
imshow(imagen1);

%visualiza la matriz
imagen1_grises = rgb2gray(imagen1);

h = fspecial('average',80); % Genera la mascara de la imagen
imagenFiltrada = imfilter(imagen1_grises,h);%realiza el filtro sobre la imagen

figure(2)
imshow(imagenFiltrada)

for I = 1:3
im_sin_luz = (imagen1(:,:,I) - imagenFiltrada)+ 127;
end


figure(3)
imshow(im_sin_luz)

