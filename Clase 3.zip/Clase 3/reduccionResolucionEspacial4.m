
%abre la imagen
imagen  = IMREAD('flor.jpg');

%convierte a grises
imagen = rgb2gray(imagen);


imagen_p = imresize(imagen,0.1);
    

imagen_N = imresize(imagen_p,10,'nearest');
imagen_BL = imresize(imagen_p,10,'bilinear');
imagen_BC = imresize(imagen_p,10,'bicubic');

%visualiza las 3 imagenes
subplot(1,3,1), imshow(imagen_N)
subplot(1,3,2), imshow(imagen_BL)
subplot(1,3,3), imshow(imagen_BC)
