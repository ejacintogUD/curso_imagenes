clc
clear all
close all
%abre las imagenes
imagen1  = imread('cesped.jpg');
imagen2  = imread('balon.jpg');
imagen3  = imread('arco.jpg');

m = size(imagen1);
balon_peque  = imresize(imagen2,0.1);

im_negra = uint8(zeros(m));

im_negra(160:199,200:259,:) = balon_peque;

im_sal = max(imagen3,im_negra);


figure()
imshow(im_sal)