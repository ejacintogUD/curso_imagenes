clc
close all
clear all

imagen = imread('semillas.jpg');    % cargo la imagen
gris = rgb2gray(imagen);            % la convierto a gris
gris_d = double(gris);             %se convierte el formato numerico a presicion doble
%     
%     if gris < 100    % se aplica la funcion para realsar el contraste
%     gris_tenue = gris_d*0.7;
%     else if  gris < 150
%     gris_tenue =  gris_d*2 - 130;
%         else
%     gris_tenue =  gris_d*0.8+51;
%         end
%     end        
%                
%     max ( max(gris_tenue));             % se calcula el maximo valor de la matriz para escalizar    
%     gris_tenue = gris_tenue* 255 /max ( max(gris_tenue));% se escaliza la imagen 
%     gris_f = uint8(gris_tenue);          % se pasa cada punto al formato numerico de la imagen   
    
   
    histograma_01 = imhist(gris);
    figure()
    plot(histograma_01)
    
    for I = 2:254
       d_hist(I) = histograma_01(I+1) -  histograma_01(I);
       d2_hist(I) = histograma_01(I+1) + histograma_01(I-1) -2*histograma_01(I);
    end 
    
    d_hist;
    d2_hist;
    
    figure()
    plot(d_hist)
    figure()
    plot(d2_hist)
    
    maxd = max(d2_hist)/4; % mitad del maximo de la primera derivada del histograma
    mind = min(d2_hist)/4; % mitad del minimo de la primera derivada del histograma
    %media_d_histmax = (max(d_hist) + min(d_hist))/2;
    
    vd_max  = find(d2_hist > maxd)
    vd_min  = find(d2_hist < mind)
    
    
    
%     plot(histograma_01);
%     
%     gris_b = (gris_tenue >= 140)*255; 
%     
%     h1 = [1,0,1;0,-1,0;1,0,1;];
%     h2 = [-1,0,1;-1,0,1;-1,0,1;];
%     
%     gris_h = imfilter(gris_b,h1);
%     gris_v = imfilter(gris_b,h2);
%     
%     
%     gris_s =  uint8(gris_h) + uint8(gris_v);   

 %visualiza  imagenes
% figure()
% subplot(1,5,1), imshow(gris)        %se muestran las imagenes
% subplot(1,5,2), imshow(gris_f)
% subplot(1,5,3), imshow(gris_b)
% subplot(1,5,3), imshow(gris_h)
% subplot(1,5,4), imshow(gris_v)
% subplot(1,5,5), imshow(gris_s)

