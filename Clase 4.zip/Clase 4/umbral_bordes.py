#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Sep 11 19:31:27 2019

@author: edward
"""

import numpy as np
import cv2
from matplotlib import pyplot as plt

#cargamos una imagen de color en modo escala de grisis
imagen = cv2.imread('balon_puma.jpg')


im_bordes = cv2.Canny(imagen, 100,200)

plt.subplot(121),plt.imshow(imagen)
plt.title('Original Image'), plt.xticks([]), plt.yticks([])
plt.subplot(122),plt.imshow(im_bordes,cmap = 'gray')
plt.title('Edge Image'), plt.xticks([]), plt.yticks([])

plt.show()
b,g,r = cv2.split(imagen)
retval, umbral = cv2.threshold(b, 160, 255, cv2.THRESH_BINARY)
cv2.imshow('Original', imagen)
cv2.imshow('Canal azul', b)
cv2.imshow('umbral azul', umbral)

cv2.waitKey(0)
cv2.destroyAllWindows()






