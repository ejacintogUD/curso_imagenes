clc

imagen = imread('bosque_bajo.jpg');    % cargo la imagen
gris = rgb2gray(imagen);                % la convierto a gris
gris_d=double(gris);                    %se convierte el formato numerico a presicion doble
    

    gris_tenue = 30*log10(1+gris_d) ;       % se aplica la funcion para realsar el contraste
    max ( max(gris_tenue))              % se calcula el maximo valor de la matriz para escalizar    
    gris_tenue = gris_tenue* 255 /max ( max(gris_tenue));% se escaliza la imagen 
    gris_f = uint8(gris_tenue);          % se pasa cada punto al formato numerico de la imagen   

    gris_exp = gris_d .^ 2.1 + 10;       % se aplica la funcion para realsar el contraste
    max ( max(gris_exp))              % se calcula el maximo valor de la matriz para escalizar    
    gris_tenue = gris_exp* 255 /max ( max(gris_tenue));% se escaliza la imagen 
    gris_g = uint8(gris_exp);          % se pasa cada punto al formato numerico de la imagen  
    
%visualiza  imagenes
subplot(1,3,1), imshow(gris)        %se muestran las imagenes
subplot(1,3,2), imshow(gris_f)
subplot(1,3,3), imshow(gris_g)

