close all;
clear all;

im = imread('reflejo_tenue_01.jpg');

hist_reflejo = imhist(im);

figure()
subplot(1,2,1), imshow(im);
subplot(1,2,2), plot(hist_reflejo);

c = 1000;

im_log = c * log10(1+ double(im));

maximo = max(max((im_log)));

im_salida = uint8((im_log/maximo)*255);
hist_salida = imhist(im_salida);

figure()
subplot(1,2,1), imshow(im_salida);
subplot(1,2,2), plot(hist_salida);















