%clase 4
%planos de bits

clc
im1 = imread('dolar.jpg');
im = rgb2gray(im1);
%rgb2gray()
bit1 = '00000001';
bit2 = '00000010';
bit3 = '00000100';
bit4 = '00001000';
bit5 = '00010000';
bit6 = '00100000';
bit7 = '01000000';
bit8 = '10000000';

imb1 = bitand(im,bin2dec(bit1))>0;
imb2 = bitand(im,bin2dec(bit2))>0;
imb3 = bitand(im,bin2dec(bit3))>0;
imb4 = bitand(im,bin2dec(bit4))>0;
imb5 = bitand(im,bin2dec(bit5))>0;
imb6 = bitand(im,bin2dec(bit6))>0;
imb7 = bitand(im,bin2dec(bit7))>0;
imb8 = bitand(im,bin2dec(bit8))>0;

subplot(3,3,1), imshow(im)
subplot(3,3,2), imshow(imb1)
subplot(3,3,3), imshow(imb2)
subplot(3,3,4), imshow(imb3)
subplot(3,3,5), imshow(imb4)
subplot(3,3,6), imshow(imb5)
subplot(3,3,7), imshow(imb6)
subplot(3,3,8), imshow(imb7)
subplot(3,3,9), imshow(imb8)

