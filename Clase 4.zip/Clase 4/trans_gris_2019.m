clc
close all 
clear all

im = imread('semillas.jpg');

im = rgb2gray(im);

histo = imhist(im);


im = im + 20;
figure(1)
imshow(im)

figure(2)
plot(histo)

c = 30;
im_d = double(im);
im_sal = double (c * log10(1 + im_d));

maximo = max(max(im_sal));

im_sal = uint8(((im_sal*255)/maximo));
histo_sal = imhist(im_sal);


figure(3)
imshow(im_sal)

figure(4)
plot(histo_sal)





