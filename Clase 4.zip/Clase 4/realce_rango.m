clc

gris = imread('torso.jpg');    % cargo la imagen
%gris = rgb2gray(imagen);            % la convierto a gris
gris_d = double(gris);             %se convierte el formato numerico a presicion doble
   
histograma =imhist(gris);
plot (histograma)

    gris_b = (gris >= 159)*255;

    if gris < 70    % se aplica la funcion para realzar el contraste
    gris_r = gris;
    else if gris < 150
    gris_r = 200;
        else
    gris_r = gris;         
        end
    end
    
%visualiza  imagenes
figure(2)
subplot(1,3,1), imshow(gris)        %se muestran las imagenes
subplot(1,3,2), imshow(gris_b)
subplot(1,3,3), imshow(gris_r)
