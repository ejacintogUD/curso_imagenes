clc
clear all
close all

im = imread('balon_puma.jpg');


m_c = fspecial('prewitt');

im_edges = imfilter(im, m_c);

figure()
imshow(im_edges)


im_b = im(:,:,3);

hist_b = imhist(im_b);

figure()
subplot(1,2,1), imshow(im_b)
subplot(1,2,2), plot(hist_b)

im_bw_l = im2bw(im_b,160/255); % threshold
im_bw_h = im2bw(im_b,200/255); % threshold

figure()
subplot(1,2,1), imshow(im_bw_l)
subplot(1,2,2), imshow(im_bw_h)

masc_bw = bitxor(im_bw_l,im_bw_h);
im_edges_masc = imfilter(masc_bw, m_c);


figure()
imshow(im_edges_masc)

% im_hc = histeq(im);
% hist_hc = imhist(im_hc);
% 
%  se = [0 1 0; 1 -4 1; 0 1 0];
% % 
%  im_sal =  imfilter(im_bw,se);
% % 
%  figure()
%  imshow(im_sal)
% 






