clc
clear all
close all

im = imread('bosque_bajo.jpg');

imgris = rgb2gray(im);
histo = imhist(imgris);


im_salida = histeq(imgris);

% imgrisdouble = double(imgris);

% c= 0.8;
% 
% 
% im_salida = c *log(1 + imgrisdouble);
% 
% 
% im_salida = im_salida / max(max(im_salida)); % matriz normalizada
% 
% 
% im_salida = uint8 (im_salida*255);

imhist_sal = imhist(im_salida);

figure()
subplot(2,2,1),imshow(imgris)
subplot(2,2,2),plot(histo)
subplot(2,2,3),imshow(im_salida)
subplot(2,2,4),plot(imhist_sal)





