clc

imagen = imread('surface_waves_01.jpg');    % cargo la imagen
gris = rgb2gray(imagen);                    % la convierto a gris
gris_d=double(gris);                    %se convierte el formato numerico a presicion doble
    gris_tenue =  gris_d .^ 8;          % se aplica la funcion para realzar el contraste
    max ( max(gris_tenue))              % se calcula el maximo valor de la matriz para escalizar    
   % gris_tenue = log10(1+gris_d);
    gris_tenue = gris_tenue* 255 /max ( max(gris_tenue));% se escaliza la imagen 
    gris_f = uint8(gris_tenue);          % se pasa cada punto al formato numerico de la imagen   

%visualiza  imagenes
subplot(1,2,1), imshow(gris)        %se muestran las imagenes
subplot(1,2,2), imshow(gris_f)

