%Realce local usando propiedades estadisticas
clc

imagen = imread('espiral.jpg');    %funcion para abrir imagenes
imagen1 = im2double(imagen);

media_g = mean(mean(imagen1));          %media y 
devStd_g = std(std(imagen1));    %desviacion estandar globales

%calcula desviacion estandar y media locales
pix = 5;
masc_prom = (1/pix^2)*ones(pix);     %filtro en vecindario de 5x5
media_l = imfilter(imagen1,masc_prom);
devStd_l = imfilter( (imagen1-media_l).^2 ,masc_prom);

%mascaras de seleccion de pixeles a resaltar
k0 = 0.8;
k2 = 0.0005;
m1 = media_l <= k0*media_g;     %region oscura
m2 = devStd_l <= k2*devStd_g;   %region bajo contraste


figure(1)
imshow(and(m1,not(m2)));
