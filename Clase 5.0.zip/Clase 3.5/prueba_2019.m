clc
close all
clear all 

im = imread('Espiral.jpg');

h_im = imhist(im);

figure()
subplot(1,2,1), imshow(im)
subplot(1,2,2), plot(h_im)

masc_oculta = 1- im2bw(im, 70/255);

im_oculta = bitand(im, uint8(masc_oculta*255))
h_im_oculta = imhist(im_oculta);


figure()
subplot(1,2,1), imshow(im_oculta)
subplot(1,2,2), plot(h_im_oculta)

im_oculta_equ = histeq(im_oculta)
h_im_oculta_equ = imhist(im_oculta_equ);


figure()
subplot(1,2,1), imshow(im_oculta_equ)
subplot(1,2,2), plot(h_im_oculta_equ)

im_salida = double(im) + double(im_oculta_equ);

maximo = max(max(im_salida));

im_salida = uint8((im_salida/maximo)*255);

figure()
imshow(im_salida)





