clc
close all
clear all

espiral = imread ('Espiral.jpg');


%Mostrar el histograma
histograma = imhist(espiral);

espiral_s = histeq(espiral);
histograma_s = imhist(espiral_s);


% Mostrar la figura
figure()
subplot(1,2,1),imshow(espiral)
subplot(1,2,2),imshow(espiral_s)

%Mostrar el histograma
figure()
subplot(1,2,1),plot(histograma)
subplot(1,2,2),plot(histograma_s)



