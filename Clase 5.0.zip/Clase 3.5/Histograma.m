clc

Grano1 = imread('Granos_01.jpg');
Grano2 = imread('Granos_02.jpg');
Grano3 = imread('Granos_03.jpg');
Grano4 = imread('Granos_04.jpg');

histograma1 = imhist(Grano1);
histograma2 = imhist(Grano2);
histograma3 = imhist(Grano3);
histograma4 = imhist(Grano4);

%visualiza  imagenes

subplot(1,2,1), imshow(Grano1);
subplot(1,2,2), plot (histograma1);

figure(2)
subplot(1,2,1), imshow(Grano2);
subplot(1,2,2), plot(histograma2);

figure(3)
subplot(1,2,1), imshow(Grano3);
subplot(1,2,2), plot(histograma3);

figure(4)
subplot(1,2,1), imshow(Grano4);
subplot(1,2,2), plot(histograma4);
