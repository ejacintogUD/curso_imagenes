clc
close all
clear all

im = imread('Lenna.png');

im = rgb2gray(im);


hist = imhist(im);

im_equ = histeq(im);

hist_equ = imhist(im_equ);


figure()
subplot(2,2,1), imshow(im)
subplot(2,2,2), plot(hist)
subplot(2,2,3), imshow(im_equ)
subplot(2,2,4), plot(hist_equ)
