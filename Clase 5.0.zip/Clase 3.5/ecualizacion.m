clc

imagen1 = imread('panoramica01.tif');

histograma1 = imhist(imagen1);

subplot(1,2,1),imshow (imagen1);
subplot(1,2,2),plot (histograma1);

imagen2 = histeq(imagen1);
histograma2 = imhist(imagen2);

figure(2)
subplot(1,2,1),imshow (imagen2);
subplot(1,2,2),plot (histograma2);






