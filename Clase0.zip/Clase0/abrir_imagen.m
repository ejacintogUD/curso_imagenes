close all
clear all
clc

imagen = imread('letra-a.jpg'); % mi primera imagen 


imagen_gris = rgb2gray (imagen);
imagen_gris = 255 - imagen_gris;

im_tinny = imresize(imagen_gris ,[50 50]);

figure()
subplot (1,2,1),imshow(imagen_gris);
subplot (1,2,2),imshow(im_tinny);

figure()
mesh(double(im_tinny));


