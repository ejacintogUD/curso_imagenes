close all
clear all
clc
im = imread ('D.jpg');
im_gris = im2gray(im);
ventana = 20;

im_salida_bin = imbinarize(im_gris, 120/255);

im_gris(im_gris<160) = 0;
    
figure()
imshow(im_gris)

figure()
imshow(im_salida_bin)








