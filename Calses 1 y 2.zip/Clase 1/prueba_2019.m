clc
clear all
close all 
im = imread('Carro_rojo.jpg');
imgris = rgb2gray(im);

im_r = im(:,:,1);
im_g = im(:,:,2);
im_b = im(:,:,3);


imbw_r = im2bw(im_r, 0.2);
imbw_g = 1- im2bw(im_g, 0.3);
imbw_b = 1- im2bw(im_b, 0.12);

im_salida = imbw_r & imbw_g & imbw_b;

figure()
subplot(1,2,1),imshow(im)
subplot(1,2,2),imshow(im_salida)


