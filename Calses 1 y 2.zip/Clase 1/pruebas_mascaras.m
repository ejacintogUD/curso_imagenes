clc

imagen1 = imread  ('D-s.jpg');% ('brain3.jpg'); %funcion para abrir imagenes

figure(1)
imshow(imagen1);

imagen1_grises = rgb2gray(imagen1)

mascara = [1 1 1; 1 -2 1; -1 -1 -1];

imsalida = imfilter(imagen1_grises,mascara);

imsalida_binaria = im2bw(imsalida);

figure()
subplot (1,3,1), imshow(imagen1)
subplot (1,3,2), imshow(imsalida)
subplot (1,3,3), imshow(imsalida_binaria)