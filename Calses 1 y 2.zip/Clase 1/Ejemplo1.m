clc 
close all
clear all

Carro = imread('Carro_rojo.jpg');

figure()
imshow(Carro)

Carro_r = Carro(:,:,1);
Carro_g = Carro(:,:,2);
Carro_b = Carro(:,:,3);

figure()
imshow(Carro_r)

Carro_out(:,:,1) = Carro_g;
Carro_out(:,:,2) = Carro_r;
Carro_out(:,:,3) = Carro_b;

figure()
imshow(Carro_out);






