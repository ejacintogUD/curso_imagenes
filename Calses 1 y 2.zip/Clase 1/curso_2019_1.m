clc
clear all
close all

im = imread('Carro_rojo.jpg');

figure()
imshow(im)
% split channels
im_r = im(:,:,1);
im_g = im(:,:,2);
im_b = im(:,:,3);

im_sal(:,:,1) = im_r;
im_sal(:,:,2) = im_r;
im_sal(:,:,3) = im_b;

figure()
imshow(im_sal);


















