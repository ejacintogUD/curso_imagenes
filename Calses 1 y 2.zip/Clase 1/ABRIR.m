%ABRIR IMAGEN
clc
im  = imread('carro_rojo.jpg');
img = rgb2gray(im);
figure(1)
imshow(im)

im_r = im(:,:,1);
 
im_g = im(:,:,2);

im_b = im(:,:,3);

figure(2)
subplot(1,3,1)
imshow(im_r)
subplot(1,3,2)
imshow(im_g)
subplot(1,3,3)
imshow(im_b)

im_color(:,:,1) = im_b;
im_color(:,:,2) = im_r;
im_color(:,:,3) = im_g;

figure(3)
imshow(im_color)

