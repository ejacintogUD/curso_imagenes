% Abrir imagen 
clc
close all
clear all

im = imread('mazda_rojo.jpg'); % read imagen 
figure()
imshow(im)

im_gris = rgb2gray(im); % pasar a gris

% split channels
im_roja  = im(:,:,1); % extracción la matriz roja 
im_verde = im(:,:,2); % extracción la matriz verde 
im_azul  = im(:,:,3); % extracción la matriz azul 

%dimenciones de la matriz
dimen = size(im_gris);

% saco el pedazo de la imagen para hacer la mascara
im_pedazo = zeros(dimen);
im_pedazo(186:290,130:314) = 1; 
im_masc_roja = bitand (im_roja, uint8(im_pedazo*255));

% Umbralizar el pedazo (queda en binario)
im_masc_roja_bin = imbinarize(im_masc_roja, 173/255);

% la recombino (para no afectar el resto de la imagen)
im_masc_salida_roja = bitand (im_roja, uint8(im_masc_roja_bin*255));
im_roja_final = im_roja + im_masc_salida_roja;

figure()
% Abrir imagen 
clc
close all
clear all

im = imread('mazda_rojo.jpg'); % read imagen 
figure()
imshow(im)

im_gris = rgb2gray(im); % pasar a gris

% split channels
im_roja  = im(:,:,1); % extracción la matriz roja 
im_verde = im(:,:,2); % extracción la matriz verde 
im_azul  = im(:,:,3); % extracción la matriz azul 

%dimenciones de la matriz
dimen = size(im_gris);

% saco el pedazo de la imagen para hacer la mascara
im_pedazo = zeros(dimen);
im_pedazo(186:290,130:314) = 1; 
im_masc_roja = bitand (im_roja, uint8(im_pedazo*255));

% Umbralizar el pedazo (queda en binario)
im_masc_roja_bin = imbinarize(im_masc_roja, 173/255);


im_masc_salida_roja = bitand (im_roja, uint8(im_masc_roja_bin*255));
figure()
imshow(im_masc_salida_roja)
 
im_bordes_rojo = edge(im_masc_roja_bin)

figure()
imshow(im_bordes_rojo)

% 
% im_roja_final = im_roja + im_masc_salida_roja;
% 
% 
% figure()
% im_salida(:,:,1) = im_verde;
% im_salida(:,:,2) = im_roja_final;
% im_salida(:,:,3) = im_azul;
% 
% figure()
% imshow(im_salida)
% 
% 
% %borde del carro
% 
% 
% % Merge de los canales 
% figure()
% im_salida(:,:,1) = im_verde;
% im_salida(:,:,2) = im_roja_final;
% im_salida(:,:,3) = im_azul;
% 
% figure()
% imshow(im_salida)
% 
% 
% 








