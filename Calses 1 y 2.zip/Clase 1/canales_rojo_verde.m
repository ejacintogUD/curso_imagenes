clc

imagen = imread('Carro_rojo.jpg');

figure()
imshow(imagen)

im_reajuste = imresize(imagen , [7 10])

figure()
imshow(im_reajuste);

im_rojo = imagen(:,:,1);

figure()
imshow(im_rojo);

im_verde = imagen(:,:,2);
figure()
imshow(im_verde);

im_azul = imagen(:,:,3);

figure()
imshow(im_azul);
