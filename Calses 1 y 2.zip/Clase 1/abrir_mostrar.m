
im = imread('Carro_rojo.jpg');

figure()
imshow(im)

imgray = rgb2gray(im);

imdouble = double(imgray);

figure()
mesh(imdouble)

im_r = im(:,:,1);
im_g = im(:,:,2);
im_b = im(:,:,3);


im_salida(:,:,1) = im_g;
im_salida(:,:,2) = im_r;
im_salida(:,:,3) = im_b;

figure()
imshow(im_salida)



