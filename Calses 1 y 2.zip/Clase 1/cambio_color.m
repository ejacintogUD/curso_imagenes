clc 
close all
clear all

carro = imread('ff.jpg');

figure()
imshow(carro);


carro_rojo  = carro(:,:,1); 
carro_verde = carro(:,:,2);
carro_azul  = carro(:,:,3); 

% 
% 
% umbral = im2bw(carro_rojo,0.6);
% 
% nueva_roja = bitand(uint8(umbral*255),carro_rojo);


carro_amarillo(:,:,1) = carro_verde;
carro_amarillo(:,:,2) = carro_rojo;
carro_amarillo(:,:,3) = carro_azul;

figure()
imshow(carro_amarillo);





